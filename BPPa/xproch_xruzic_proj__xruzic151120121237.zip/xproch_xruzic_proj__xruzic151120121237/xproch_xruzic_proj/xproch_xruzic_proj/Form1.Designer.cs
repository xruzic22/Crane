﻿namespace xproch_xruzic_proj
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.K1L = new System.Windows.Forms.Label();
            this.K2L = new System.Windows.Forms.Label();
            this.K3L = new System.Windows.Forms.Label();
            this.K4L = new System.Windows.Forms.Label();
            this.K5L = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.obr_magnet = new System.Windows.Forms.Button();
            this.obr_L = new System.Windows.Forms.Button();
            this.obr_M = new System.Windows.Forms.Button();
            this.obr_B = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stop = new System.Windows.Forms.Button();
            this.right = new System.Windows.Forms.Button();
            this.left = new System.Windows.Forms.Button();
            this.down = new System.Windows.Forms.Button();
            this.up = new System.Windows.Forms.Button();
            this.mag = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Lstepper_down = new System.Windows.Forms.Label();
            this.Lstepper_up = new System.Windows.Forms.Label();
            this.LDC_right = new System.Windows.Forms.Label();
            this.LDC_left = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.doraz_mag = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rychlost = new System.Windows.Forms.ComboBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // K1L
            // 
            this.K1L.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.K1L.Location = new System.Drawing.Point(12, 228);
            this.K1L.Name = "K1L";
            this.K1L.Size = new System.Drawing.Size(30, 15);
            this.K1L.TabIndex = 6;
            this.K1L.Text = "K1";
            // 
            // K2L
            // 
            this.K2L.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.K2L.Location = new System.Drawing.Point(197, 228);
            this.K2L.Name = "K2L";
            this.K2L.Size = new System.Drawing.Size(30, 15);
            this.K2L.TabIndex = 7;
            this.K2L.Text = "K2";
            // 
            // K3L
            // 
            this.K3L.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.K3L.Location = new System.Drawing.Point(397, 228);
            this.K3L.Name = "K3L";
            this.K3L.Size = new System.Drawing.Size(30, 15);
            this.K3L.TabIndex = 8;
            this.K3L.Text = "K3";
            // 
            // K4L
            // 
            this.K4L.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.K4L.Location = new System.Drawing.Point(597, 228);
            this.K4L.Name = "K4L";
            this.K4L.Size = new System.Drawing.Size(30, 15);
            this.K4L.TabIndex = 9;
            this.K4L.Text = "K4";
            // 
            // K5L
            // 
            this.K5L.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.K5L.Location = new System.Drawing.Point(782, 228);
            this.K5L.Name = "K5L";
            this.K5L.Size = new System.Drawing.Size(30, 15);
            this.K5L.TabIndex = 10;
            this.K5L.Text = "K5";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 23);
            this.label8.TabIndex = 0;
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.obr_magnet);
            this.panel1.Controls.Add(this.obr_L);
            this.panel1.Controls.Add(this.obr_M);
            this.panel1.Controls.Add(this.obr_B);
            this.panel1.Location = new System.Drawing.Point(12, 246);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 300);
            this.panel1.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(408, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            // 
            // obr_magnet
            // 
            this.obr_magnet.BackColor = System.Drawing.Color.Black;
            this.obr_magnet.Location = new System.Drawing.Point(0, 0);
            this.obr_magnet.Name = "obr_magnet";
            this.obr_magnet.Size = new System.Drawing.Size(30, 60);
            this.obr_magnet.TabIndex = 3;
            this.obr_magnet.UseVisualStyleBackColor = false;
            // 
            // obr_L
            // 
            this.obr_L.Location = new System.Drawing.Point(185, 224);
            this.obr_L.Name = "obr_L";
            this.obr_L.Size = new System.Drawing.Size(30, 25);
            this.obr_L.TabIndex = 2;
            this.obr_L.UseVisualStyleBackColor = true;
            // 
            // obr_M
            // 
            this.obr_M.Location = new System.Drawing.Point(170, 249);
            this.obr_M.Name = "obr_M";
            this.obr_M.Size = new System.Drawing.Size(60, 25);
            this.obr_M.TabIndex = 1;
            this.obr_M.UseVisualStyleBackColor = true;
            // 
            // obr_B
            // 
            this.obr_B.Location = new System.Drawing.Point(155, 274);
            this.obr_B.Name = "obr_B";
            this.obr_B.Size = new System.Drawing.Size(90, 25);
            this.obr_B.TabIndex = 0;
            this.obr_B.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.stop);
            this.groupBox1.Controls.Add(this.right);
            this.groupBox1.Controls.Add(this.left);
            this.groupBox1.Controls.Add(this.down);
            this.groupBox1.Controls.Add(this.up);
            this.groupBox1.Controls.Add(this.mag);
            this.groupBox1.Location = new System.Drawing.Point(496, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(316, 131);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ovladaci prvky";
            // 
            // stop
            // 
            this.stop.BackColor = System.Drawing.Color.Red;
            this.stop.Location = new System.Drawing.Point(216, 48);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(44, 32);
            this.stop.TabIndex = 19;
            this.stop.Text = "STOP";
            this.stop.UseVisualStyleBackColor = false;
            this.stop.Click += new System.EventHandler(this.stop_Click);
            // 
            // right
            // 
            this.right.Location = new System.Drawing.Point(266, 48);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(44, 32);
            this.right.TabIndex = 18;
            this.right.Text = "R";
            this.right.UseVisualStyleBackColor = true;
            this.right.Click += new System.EventHandler(this.right_Click);
            // 
            // left
            // 
            this.left.Location = new System.Drawing.Point(166, 48);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(44, 32);
            this.left.TabIndex = 17;
            this.left.Text = "L";
            this.left.UseVisualStyleBackColor = true;
            this.left.Click += new System.EventHandler(this.left_Click);
            // 
            // down
            // 
            this.down.Location = new System.Drawing.Point(216, 86);
            this.down.Name = "down";
            this.down.Size = new System.Drawing.Size(44, 32);
            this.down.TabIndex = 16;
            this.down.Tag = "0";
            this.down.Text = "D";
            this.down.UseVisualStyleBackColor = true;
            this.down.Click += new System.EventHandler(this.down_Click);
            // 
            // up
            // 
            this.up.Location = new System.Drawing.Point(216, 10);
            this.up.Name = "up";
            this.up.Size = new System.Drawing.Size(44, 32);
            this.up.TabIndex = 15;
            this.up.Tag = "0";
            this.up.Text = "U";
            this.up.UseVisualStyleBackColor = true;
            this.up.Click += new System.EventHandler(this.up_Click);
            // 
            // mag
            // 
            this.mag.Location = new System.Drawing.Point(6, 53);
            this.mag.Name = "mag";
            this.mag.Size = new System.Drawing.Size(75, 23);
            this.mag.TabIndex = 1;
            this.mag.Tag = "0";
            this.mag.Text = "magnet";
            this.mag.UseVisualStyleBackColor = true;
            this.mag.Click += new System.EventHandler(this.mag_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.Lstepper_down);
            this.groupBox2.Controls.Add(this.Lstepper_up);
            this.groupBox2.Controls.Add(this.LDC_right);
            this.groupBox2.Controls.Add(this.LDC_left);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.doraz_mag);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(310, 131);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kontrolky";
            // 
            // Lstepper_down
            // 
            this.Lstepper_down.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lstepper_down.Location = new System.Drawing.Point(120, 113);
            this.Lstepper_down.Name = "Lstepper_down";
            this.Lstepper_down.Size = new System.Drawing.Size(80, 15);
            this.Lstepper_down.TabIndex = 17;
            this.Lstepper_down.Text = "stepper_down";
            // 
            // Lstepper_up
            // 
            this.Lstepper_up.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lstepper_up.Location = new System.Drawing.Point(120, 16);
            this.Lstepper_up.Name = "Lstepper_up";
            this.Lstepper_up.Size = new System.Drawing.Size(80, 15);
            this.Lstepper_up.TabIndex = 16;
            this.Lstepper_up.Text = "stepper_up";
            // 
            // LDC_right
            // 
            this.LDC_right.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LDC_right.Location = new System.Drawing.Point(224, 57);
            this.LDC_right.Name = "LDC_right";
            this.LDC_right.Size = new System.Drawing.Size(80, 15);
            this.LDC_right.TabIndex = 15;
            this.LDC_right.Text = "DC_right";
            this.LDC_right.Click += new System.EventHandler(this.LDC_right_Click);
            // 
            // LDC_left
            // 
            this.LDC_left.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LDC_left.Location = new System.Drawing.Point(6, 57);
            this.LDC_left.Name = "LDC_left";
            this.LDC_left.Size = new System.Drawing.Size(80, 15);
            this.LDC_left.TabIndex = 14;
            this.LDC_left.Text = "DC_left";
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(6, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Mag_Imp";
            // 
            // doraz_mag
            // 
            this.doraz_mag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.doraz_mag.Location = new System.Drawing.Point(6, 16);
            this.doraz_mag.Name = "doraz_mag";
            this.doraz_mag.Size = new System.Drawing.Size(60, 15);
            this.doraz_mag.TabIndex = 12;
            this.doraz_mag.Text = "Mag_UP";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.radioButton3);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Location = new System.Drawing.Point(12, 191);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 34);
            this.panel2.TabIndex = 17;
            this.panel2.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "final position:";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Location = new System.Drawing.Point(585, 12);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(384, 12);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(185, 12);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.radioButton4);
            this.panel3.Controls.Add(this.radioButton5);
            this.panel3.Controls.Add(this.radioButton6);
            this.panel3.Location = new System.Drawing.Point(12, 151);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(800, 34);
            this.panel3.TabIndex = 18;
            this.panel3.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "start position:";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(585, 12);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 2;
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(384, 12);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 1;
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(185, 12);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(14, 13);
            this.radioButton6.TabIndex = 0;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.rychlost);
            this.groupBox3.Controls.Add(this.radioButton8);
            this.groupBox3.Controls.Add(this.radioButton7);
            this.groupBox3.Location = new System.Drawing.Point(328, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(162, 131);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ovládání";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Rychlost pojezdu";
            // 
            // rychlost
            // 
            this.rychlost.FormattingEnabled = true;
            this.rychlost.Items.AddRange(new object[] {
            "slow",
            "medium",
            "high"});
            this.rychlost.Location = new System.Drawing.Point(6, 104);
            this.rychlost.Name = "rychlost";
            this.rychlost.Size = new System.Drawing.Size(121, 21);
            this.rychlost.TabIndex = 21;
            this.rychlost.Text = "medium";
            this.rychlost.SelectedIndexChanged += new System.EventHandler(this.rychlost_SelectedIndexChanged_2);
            this.rychlost.SelectedValueChanged += new System.EventHandler(this.rychlost_SelectedValueChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(6, 42);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(76, 17);
            this.radioButton8.TabIndex = 1;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Algoritmem";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Checked = true;
            this.radioButton7.Location = new System.Drawing.Point(6, 19);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(55, 17);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Ruční";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(120, 59);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(96, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 23);
            this.button2.TabIndex = 23;
            this.button2.Text = "Run";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 558);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.K5L);
            this.Controls.Add(this.K4L);
            this.Controls.Add(this.K3L);
            this.Controls.Add(this.K2L);
            this.Controls.Add(this.K1L);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hanojské věže";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label K1L;
        private System.Windows.Forms.Label K2L;
        private System.Windows.Forms.Label K3L;
        private System.Windows.Forms.Label K4L;
        private System.Windows.Forms.Label K5L;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button obr_magnet;
        private System.Windows.Forms.Button obr_L;
        private System.Windows.Forms.Button obr_M;
        private System.Windows.Forms.Button obr_B;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button stop;
        private System.Windows.Forms.Button right;
        private System.Windows.Forms.Button left;
        private System.Windows.Forms.Button down;
        private System.Windows.Forms.Button up;
        private System.Windows.Forms.Button mag;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label Lstepper_down;
        private System.Windows.Forms.Label Lstepper_up;
        private System.Windows.Forms.Label LDC_right;
        private System.Windows.Forms.Label LDC_left;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label doraz_mag;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox rychlost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

